#
# @lc app=leetcode.cn id=12 lang=python
# @lcpr version=30005
#
# [12] 整数转罗马数字
#


# @lcpr-template-start

# @lcpr-template-end
# @lc code=start
class Solution(object):
    def intToRoman(self, num):
        """
        :type num: int
        :rtype: str
        """
        num_M, remain = num / 1000, num % 1000
        num_D, remain = remain / 500, remain % 500
        num_C, remain = remain / 100, remain % 100
        num_L, remain = remain / 50, remain % 50
        num_X, remain = remain / 10, remain % 10
        num_V, remain = remain / 5, remain % 5
        num_I, remain = remain / 1, remain % 1
        
# @lc code=end



#
# @lcpr case=start
# 3749\n
# @lcpr case=end

# @lcpr case=start
# 58\n
# @lcpr case=end

# @lcpr case=start
# 1994\n
# @lcpr case=end

#

