#
# @lc app=leetcode.cn id=54 lang=python
# @lcpr version=30104
#
# [54] 螺旋矩阵
#

# @lc code=start
class Solution(object):
    def spiralOrder(self, matrix):
        """
        :type matrix: List[List[int]]
        :rtype: List[int]
        """
        output_list = []
        ## 一种思想：每次从左到右遍历第一行数据，并把第一行数据pop出去 
        #           然后向左旋转90°
        while matrix:
            ## 从左到右遍历第一行
            output_list.extend(matrix[0])
            matrix.pop(0)
            # 向左旋转90°
            matrix = list(map(list, zip(*matrix)))[::-1]
            # print("matrix----------", matrix)
            # print("output_list-----", output_list)

        return output_list
        
# @lc code=end



#
# @lcpr case=start
# [[1,2,3],[4,5,6],[7,8,9]]\n
# @lcpr case=end

# @lcpr case=start
# [[1,2,3,4],[5,6,7,8],[9,10,11,12]]\n
# @lcpr case=end

#

