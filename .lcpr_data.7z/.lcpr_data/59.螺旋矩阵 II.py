#
# @lc app=leetcode.cn id=59 lang=python
# @lcpr version=30104
#
# [59] 螺旋矩阵 II
#

# @lc code=start
class Solution(object):
    def generateMatrix(self, n):
        """
        :type n: int
        :rtype: List[List[int]]
        """
        matrix = [[]]
        input_list = list(i for i in range(1, n**2+1))[::-1] ## 倒序
        length = [2, 1]
        for i in range(2, 2*n-1):
            ## 如果是最后三个
            if i>=2*n-4 and i<=2*n-2:
                length.append(n-1)
            else:
                length.append(int((i+2)/2))
        
        ## 每次添加l+1个数(l+1 < n)，第一行.extend(最后一个数)，矩阵顺时针旋转90°
        while input_list and length:
            l = length[0]
            length.pop(0)
            ## 去零
            for i, m in enumerate(matrix):
                matrix[i] = list(filter(lambda x :x!=0, m))

            for i in range(len(matrix)):
                matrix[i].extend(input_list[:l] if i == 0 else [0])

            matrix = [list(reversed(i)) for i in matrix]
            del input_list[:l]
            if not input_list:
                break
            matrix = list(map(list, zip(*matrix)))

        ## 去零
        for i, m in enumerate(matrix):
            matrix[i] = list(filter(lambda x :x!=0, m))
        return matrix

        
# @lc code=end



#
# @lcpr case=start
# 3\n
# @lcpr case=end

# @lcpr case=start
# 1\n
# @lcpr case=end

#

