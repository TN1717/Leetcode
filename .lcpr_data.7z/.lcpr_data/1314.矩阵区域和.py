#
# @lc app=leetcode.cn id=1314 lang=python
# @lcpr version=30200
#
# [1314] 矩阵区域和
#

# @lc code=start
class Solution(object):
    def matrixBlockSum(self, mat, k):
        """
        :type mat: List[List[int]]
        :type k: int
        :rtype: List[List[int]]
        """
        m = len(mat)
        n = len(mat[0])
        sumMat = [[0]*(n+1) for _ in range(m+1)]
        answer = [[0]*(n) for _ in range(m)]
        for i in range(m+1):
            for j in range(n+1):
                sumMat[i][j] = sumMat[i][j-1] + sumMat[i-1][j] - sumMat[i-1][j-1] + mat[i-1][j-1]
        for i in range(m):
            for j in range(n):
                row1 = i-k if i-k > 0 else 0
                row2 = i+k if i+k < m else m-1
                col1 = j-k if j-k > 0 else 0
                col2 = j+k if j+k < n else n-1

                answer[i][j] = sumMat[row2+1][col2+1] + sumMat[row1][col1] - sumMat[row1][col2+1]-sumMat[row2+1][col1]
        return answer
        
        
# @lc code=end



#
# @lcpr case=start
# [[1,2,3],[4,5,6],[7,8,9]]\n1\n
# @lcpr case=end

# @lcpr case=start
# [[1,2,3],[4,5,6],[7,8,9]]\n2\n
# @lcpr case=end

#

