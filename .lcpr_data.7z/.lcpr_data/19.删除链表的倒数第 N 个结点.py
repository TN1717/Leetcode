#
# @lc app=leetcode.cn id=19 lang=python
# @lcpr version=30006
#
# [19] 删除链表的倒数第 N 个结点
#


# @lcpr-template-start

# @lcpr-template-end
# @lc code=start
# Definition for singly-linked list.
# class ListNode(object):
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution(object):
    def removeNthFromEnd(self, head, n):
        """
        :type head: Optional[ListNode]
        :type n: int
        :rtype: Optional[ListNode]
        """
        # 链表拆分问题
        p = dummy = ListNode(-1)       # 存放左侧的ListNode
        head_p = head
        node_len = count = 0
        while head_p:
            head_p = head_p.next
            node_len += 1

        while head:
            if count == node_len - n:
                head = head.next
            else:
                print(count, " ", head.val)
                temp = head.next
                head.next = None
                p.next = head
                head = temp
                p = p.next
            count += 1
        # if node_len - n == 1:
        #     p.next = None
        return dummy.next

        
# @lc code=end



#
# @lcpr case=start
# [1,2,3,4,5]\n2\n
# @lcpr case=end

# @lcpr case=start
# [1]\n1\n
# @lcpr case=end

# @lcpr case=start
# [1,2]\n1\n
# @lcpr case=end

#

