#
# @lc app=leetcode.cn id=560 lang=python
# @lcpr version=30200
#
# [560] 和为 K 的子数组
#

# @lc code=start
class Solution(object):
    def subarraySum(self, nums, k):
        """
        :type nums: List[int]
        :type k: int
        :rtype: int
        """
        
        presum_nums = [0]
        res = 0
        ## 前缀和：次数
        interval_presum = {0:1}        

        for i in range(len(nums)):
            presum_nums.append(nums[i] + presum_nums[i])
            k_presum = presum_nums[-1] - k
            res += interval_presum.get(k_presum, 0)
            interval_presum[presum_nums[-1]] = interval_presum.get(presum_nums[-1], 0) + 1
        return res

        
# @lc code=end


#
# @lcpr case=start
# [-1,-1,1]\n0\n
# @lcpr case=end

# @lcpr case=start
# [1,2,3]\n3\n
# @lcpr case=end

#

