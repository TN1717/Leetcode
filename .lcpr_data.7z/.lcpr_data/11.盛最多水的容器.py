#
# @lc app=leetcode.cn id=11 lang=python
# @lcpr version=30005
#
# [11] 盛最多水的容器
#


# @lcpr-template-start

# @lcpr-template-end
# @lc code=start
class Solution(object):
    def maxArea(self, height):
        """
        :type height: List[int]
        :rtype: int
        """
        # # 找两个数a, b max{|I(a)-I(b)| × min(a, b)}
        # # max_1
        # tmp_dict = {b: c for a, b in enumerate(height)} # v:index
        # print(tmp_dict)
        # 双指针
        left, right = 0, len(height)-1
        area = 0
        while left < right:
            cruve = min(height[left], height[right]) * (right - left)
            area = max(cruve, area)
            if height[left] <= height[right]:
                left += 1
            else:
                right -= 1
        return area
        
# @lc code=end



#
# @lcpr case=start
# [1,8,6,2,5,4,8,3,7]\n
# @lcpr case=end

# @lcpr case=start
# [1,1]\n
# @lcpr case=end

#

