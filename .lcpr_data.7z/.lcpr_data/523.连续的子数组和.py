#
# @lc app=leetcode.cn id=523 lang=python
# @lcpr version=30200
#
# [523] 连续的子数组和
#

# @lc code=start
class Solution(object):
    def checkSubarraySum(self, nums, k):
        """
        :type nums: List[int]
        :type k: int
        :rtype: bool
        """
        ## 先计算前缀和数组
        presum_nums = [0]
        for i in range(len(nums)):
            presum_nums.append(nums[i]+presum_nums[i])
        ## 建立余数：index的前缀和索引dict，若index相减大于2则返回true
        remaind_index = {}
        for i in range(len(presum_nums)):
            remaind = presum_nums[i] % k
            if remaind not in remaind_index:
                remaind_index[remaind] = i
            else:
                if (i - remaind_index[remaind]) >= 2:
                    return True
        return False
        
# @lc code=end



#
# @lcpr case=start
# [23,2,4,6,7]\n6\n
# @lcpr case=end

# @lcpr case=start
# [23,2,6,4,7]\n6\n
# @lcpr case=end

# @lcpr case=start
# [23,2,6,4,7]\n13\n
# @lcpr case=end

#

