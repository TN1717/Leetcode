#
# @lc app=leetcode.cn id=5 lang=python
# @lcpr version=30005
#
# [5] 最长回文子串
#


# @lcpr-template-start

# @lcpr-template-end
# @lc code=start
class Solution(object):
    def palindrome(self, s, l, r):
        while l >= 0 and r < len(s) and s[l] == s[r]:
            l -= 1
            r += 1
        return s[l + 1 : r] 

    def longestPalindrome(self, s):
        """
        :type s: str
        :rtype: str
        """
        res =""
        for i in range(len(s)):
            # 分奇偶回文情况
            # 以s[i]为中心
            s_odd = self.palindrome(s, i, i)
            s_even = self.palindrome(s, i, i+1)

            res = res if len(res) > len(s_odd) else s_odd
            res = res if len(res) > len(s_even) else s_even

        return res

        
# @lc code=end



#
# @lcpr case=start
# "babad"\n
# @lcpr case=end

# @lcpr case=start
# "cbbd"\n
# @lcpr case=end

#

