#
# @lc app=leetcode.cn id=1124 lang=python
# @lcpr version=30200
#
# [1124] 表现良好的最长时间段
#

# @lc code=start
class Solution(object):
    def longestWPI(self, hours):
        """
        :type hours: List[int]
        :rtype: int
        """
        ## 找到一个最大区间 其中大于8的元素个数大于其他元素个数
        ## 前处理：大于8 = +1 小于8 = -1, 随后计算前缀和
        presum_hours = [0]
        for i in range(len(hours)):
            h = 1 if hours[i] > 8 else -1
            presum_hours.append(h+presum_hours[i])          ## 计算前缀和
        max_len = 0
        value_index = {}
        for i in range(len(presum_hours)):
            if presum_hours[i] not in value_index:
                value_index[presum_hours[i]] = i
            ## 在value_index 中找小于当前前缀和的序号最小的元素
            min_idx = i
            for v, idx in value_index.items():
                if v < presum_hours[i]:
                    min_idx = min(min_idx, idx)
            max_len = max(max_len, i - min_idx)
        return max_len
        
# @lc code=end



#
# @lcpr case=start
# [9,9,6,0,6,6,9]\n
# @lcpr case=end

# @lcpr case=start
# [6,6,6]\n
# @lcpr case=end

#

