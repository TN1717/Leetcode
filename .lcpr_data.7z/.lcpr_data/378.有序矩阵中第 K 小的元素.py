#
# @lc app=leetcode.cn id=378 lang=python
# @lcpr version=30006
#
# [378] 有序矩阵中第 K 小的元素
#


# @lcpr-template-start

# @lcpr-template-end
# @lc code=start

# import queue
import heapq

class Solution(object):
    
    def kthSmallest(self, matrix, k):
        """
        :type matrix: List[List[int]]
        :type k: int
        :rtype: int
        """
        # from queue import PriorityQueue
        q = []

        for i in range(len(matrix)):
            heapq.heappush(q, (matrix[i][0], i, 0))
        
        res = -1

        while q and k > 0:
            cur = heapq.heappop(q)
            res = cur[0]
            k -= 1
            i, j = cur[1], cur[2]
            if j + 1 <len(matrix[i]):
                heapq.heappush(q, (matrix[i][j+1], i, j+1))
        return res
        

        
# @lc code=end



#
# @lcpr case=start
# [[1,5,9],[10,11,13],[12,13,15]]\n8\n
# @lcpr case=end

# @lcpr case=start
# [[-5]]\n1\n
# @lcpr case=end

#

