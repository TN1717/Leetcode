#
# @lc app=leetcode.cn id=82 lang=python
# @lcpr version=30006
#
# [82] 删除排序链表中的重复元素 II
#


# @lcpr-template-start

# @lcpr-template-end
# @lc code=start
# Definition for singly-linked list.
# class ListNode(object):
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution(object):
    def deleteDuplicates(self, head):
        """
        :type head: Optional[ListNode]
        :rtype: Optional[ListNode]
        """

        # ## 递归解法
        if head is None or head.next is None:
            return head

        if head.val != head.next.val:
            head.next = self.deleteDuplicates(head.next)
            return head

        while head.next is not None and head.val == head.next.val:
            head = head.next

        return self.deleteDuplicates(head.next)

        ## 通用解法
        # p_uni = dummy_uni = ListNode(-100)
        # p_rep = dummy_rep = ListNode(-100)

        # p = head

        # while head:
        #     if (head.next != None and head.next.val == head.val) or (head.val == p_rep.val):
        #         p_rep.next = head
        #         p_rep = p_rep.next
        #     else:
        #         p_uni.next = head
        #         p_uni = p_uni.next

        #     head = head.next
        #     p_uni.next = None
        #     p_rep.next = None

        # return dummy_uni.next

# @lc code=end



#
# @lcpr case=start
# [1,2,3,3,4,4,5]\n
# @lcpr case=end

# @lcpr case=start
# [1,1,1,2,3]\n
# @lcpr case=end

#

