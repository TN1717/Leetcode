#
# @lc app=leetcode.cn id=14 lang=python
# @lcpr version=30200
#
# [14] 最长公共前缀
#

# @lc code=start
class Solution(object):
    def longestCommonPrefix(self, strs):
        """
        :type strs: List[str]
        :rtype: str
        """
        prefix = strs[0]
        for sample in strs:
            min_len = min([len(sample), len(prefix)])
            if min_len > 0 and sample[0] == prefix[0]:
                for i in range(min_len):
                    if prefix[i] != sample[i]:
                        prefix = sample[:i]
                        break
                if len(prefix) > len(sample):
                    prefix = sample
            else:
                prefix = ""
                        
        return prefix
        
# @lc code=end


#
# @lcpr case=start
# ["flower","flow","flight"]\n
# @lcpr case=end

# @lcpr case=start
# ["dog","racecar","car"]\n
# @lcpr case=end

#

