#
# @lc app=leetcode.cn id=LCR 146 lang=python
# @lcpr version=30200
#
# [LCR 146] 螺旋遍历二维数组
#

# @lc code=start
class Solution(object):
    def spiralArray(self, array):
        """
        :type array: List[List[int]]
        :rtype: List[int]
        """
        output_list = []
        while array:
            output_list.extend(array[0])
            array.pop(0)
            array = list(map(list, zip(*array)))[::-1]
            print(array)
        return output_list
        
# @lc code=end



#
# @lcpr case=start
# [[1,2,3],[8,9,4],[7,6,5]]\n
# @lcpr case=end

# @lcpr case=start
# [[1,2,3,4],[12,13,14,5],[11,16,15,6],[10,9,8,7]]\n
# @lcpr case=end

#

