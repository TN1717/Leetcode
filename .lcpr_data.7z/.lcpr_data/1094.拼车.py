#
# @lc app=leetcode.cn id=1094 lang=python
# @lcpr version=30200
#
# [1094] 拼车
#

# @lc code=start
class Solution(object):
    def carPooling(self, trips, capacity):
        """
        :type trips: List[List[int]]
        :type capacity: int
        :rtype: bool
        """
        ## 起始点list
        start_list = []
        end_list = []
        num_list = []
        for i in trips:
            num_list.append(i[0])
            start_list.append(i[1])
            end_list.append(i[2])
        print(start_list)
        print(end_list)
        print(num_list)
        ## 遍历起点
        for i in range(len(start_list)):
            start = start_list[i]
            end = end_list[i]
            ## 如果有某一个起点
            for j in range(len(start_list)):
                if j != i and start_list[j] > start and start_list[j] < end:
                    if num_list[i] +num_list[j] > capacity:
                        return False     
        return True
        
# @lc code=end



#
# @lcpr case=start
# [[2,1,5],[3,3,7]]\n4\n
# @lcpr case=end

# @lcpr case=start
# [[2,1,5],[3,3,7]]\n5\n
# @lcpr case=end

#

