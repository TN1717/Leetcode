#
# @lc app=leetcode.cn id=264 lang=python
# @lcpr version=30006
#
# [264] 丑数 II
#


# @lcpr-template-start

# @lcpr-template-end
# @lc code=start
class Solution(object):
    def nthUglyNumber(self, n):
        """
        :type n: int
        :rtype: int
        """

        p2, p3, p5 = 1, 1, 1
        num2, num3, num5 = 1, 1, 1
        i = 1
        uglynum = [0] * (n + 1)

        while i <= n:
            min_num = min(num2, num3, num5)
            uglynum[i] = min_num
            i += 1
            if min_num == num2:
                num2 = 2 * uglynum[p2]
                p2 += 1
            if min_num == num3:
                num3 = 3 * uglynum[p3]
                p3 += 1
            if min_num == num5:
                num5 = 5 * uglynum[p5]
                p5 += 1
        return uglynum[n]
        
# @lc code=end



#
# @lcpr case=start
# 10\n
# @lcpr case=end

# @lcpr case=start
# 1\n
# @lcpr case=end

#

