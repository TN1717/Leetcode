#
# @lc app=leetcode.cn id=373 lang=python
# @lcpr version=30100
#
# [373] 查找和最小的 K 对数字
#
import heapq

# @lc code=start
class Solution(object):
    def kSmallestPairs(self, nums1, nums2, k):
       # 存储三元组 (num1[i], nums2[i], i)
        # i 记录 nums2 元素的索引位置，用于生成下一个节点
        pq = []
        
        # 按照 23 题的逻辑初始化优先级队列
        for i in range(len(nums1)):
            heapq.heappush(pq, (nums1[i] + nums2[0], nums1[i], nums2[0], 0))

        res = []
        # 执行合并多个有序链表的逻辑
        while pq and k > 0:
            _, num1, num2, idx = heapq.heappop(pq)
            k -= 1
            # 链表中的下一个节点加入优先级队列
            next_index = idx + 1
            if next_index < len(nums2):
                heapq.heappush(pq, (num1 + nums2[next_index], num1, nums2[next_index], next_index))

            # 按照数对的元素和升序排序
            pair = [num1, num2]
            res.append(pair)

        return res
            
        
# @lc code=end



#
# @lcpr case=start
# [1,7,11]\n[2,4,6]\n3\n
# @lcpr case=end

# @lcpr case=start
# [1,1,2]\n[1,2,3]\n2\n
# @lcpr case=end

#

