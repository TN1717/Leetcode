#
# @lc app=leetcode.cn id=33 lang=python
# @lcpr version=30104
#
# [33] 搜索旋转排序数组
#

# @lc code=start
class Solution(object):
    def search(self, nums, target):
        """
        :type nums: List[int]
        :type target: int
        :rtype: int
        """

        ## 存在两个递增区间，[a_min, MAX], [MIN, b_max]

        # a_min = (0, nums[0])
        # b_max = (len(nums)-1, nums[-1])
        # p = 0
        # while 1:
        #    if nums[p] > nums[p+1]:
        #        MAX = (p, nums[p])
        #        MIN = (p+1, nums[p+1])
        #        break 
        #    p += 1
        # if target < MIN[1] or target > MAX[1]:
        #     return -1
        # elif target >= a_min[1] and target <=MAX[1]:
        #     if target not in nums[a_min[0]:MAX[0]]:
        #         return -1
        #     for data in nums[a_min[0]:MAX[0]]:
        #         if data == target:
        #             return

        left, right = 0, len(nums)-1
        while left <= right:
            mid = left + (right - left) // 2
            if nums[mid] == target:
                return mid
            if nums[mid] >= nums[left]:
                if target >= nums[left] and target < nums[mid]:
                    right = mid - 1
                else:
                    left = mid + 1
            else:
                if target <= nums[right] and target > nums[mid]:
                    left = mid + 1
                else:
                    right = mid - 1
        return -1

        
# @lc code=end



#
# @lcpr case=start
# [4,5,6,7,0,1,2]\n0\n
# @lcpr case=end

# @lcpr case=start
# [4,5,6,7,0,1,2]\n3\n
# @lcpr case=end

# @lcpr case=start
# [1]\n0\n
# @lcpr case=end

#

