#
# @lc app=leetcode.cn id=23 lang=python
# @lcpr version=30005
#
# [23] 合并 K 个升序链表
#


# @lcpr-template-start

# @lcpr-template-end
# @lc code=start
# Definition for singly-linked list.
# class ListNode(object):
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution(object):
    def mergeKLists(self, lists):
        """
        :type lists: List[Optional[ListNode]]
        :rtype: Optional[ListNode]
        """
        p = dummy = ListNode(-1)                        # 创建虚拟节点
        k_Node = [listnode for listnode in lists]       # K个链表的指针
        # k个指针分别指向链表 取每个链表的最小元素进行排序
        # print(len(k_Node))
        
        while len(k_Node) > 0:
            k_Node = list(filter(None, k_Node))
            if len(k_Node) == 0:
                break
            # 找k个Node中最小的节点并更新
            value = [node.val for node in k_Node]
            # print(value)
            min_idx = value.index(min(value))
            # print(k_Node[min_idx].val)

            p.next = k_Node[min_idx]
            p = p.next
            k_Node[min_idx] = k_Node[min_idx].next

        # print(dummy.next)
        
        return dummy.next
            
            
        
# @lc code=end



#
# @lcpr case=start
# [[1,4,5],[1,3,4],[2,6]]\n
# @lcpr case=end

# @lcpr case=start
# []\n
# @lcpr case=end

# @lcpr case=start
# [[]]\n
# @lcpr case=end

#

