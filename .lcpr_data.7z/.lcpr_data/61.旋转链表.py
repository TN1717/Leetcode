#
# @lc app=leetcode.cn id=61 lang=python
# @lcpr version=30104
#
# [61] 旋转链表
#

# @lc code=start
# Definition for singly-linked list.
# class ListNode(object):
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution(object):
    def rotateRight(self, head, k):
        """
        :type head: Optional[ListNode]
        :type k: int
        :rtype: Optional[ListNode]
        """
        ## 先遍历一遍找链表的深度l，将k对深度l取余数，复制一个链表并将原链表连到复制链表后，计算起始点和终止点，将中间的链表取出来
        start = end = 0
        h = head
        # print(head)
        p = dummy = ListNode(-1)
        
        while h:
            p.next = ListNode(h.val)
            h = h.next
            p = p.next
            end += 1
        
        start = end - k%end if end != 0 else 0
        end = start + end
        p.next = head
        # print(start, end)
        # print(dummy.next)
        i = 0
        while i <= end:
            if i <= start:
                p = dummy = dummy.next
            elif i == end:
                dummy.next = None
            else:
                dummy = dummy.next
            i += 1
        
        print(p)
        return p
        
        
# @lc code=end



#
# @lcpr case=start
# [1,2,3,4,5]\n2\n
# @lcpr case=end

# @lcpr case=start
# [0,1,2]\n4\n
# @lcpr case=end

#

