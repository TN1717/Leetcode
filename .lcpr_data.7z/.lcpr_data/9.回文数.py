#
# @lc app=leetcode.cn id=9 lang=python
# @lcpr version=30005
#
# [9] 回文数
#


# @lcpr-template-start

# @lcpr-template-end
# @lc code=start
class Solution(object):
    def isPalindrome(self, x):
        """
        :type x: int
        :rtype: bool
        """
        
# @lc code=end



#
# @lcpr case=start
# 121\n
# @lcpr case=end

# @lcpr case=start
# -121\n
# @lcpr case=end

# @lcpr case=start
# 10\n
# @lcpr case=end

#

