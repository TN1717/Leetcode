#
# @lc app=leetcode.cn id=1352 lang=python
# @lcpr version=30200
#
# [1352] 最后 K 个数的乘积
#

# @lc code=start
class ProductOfNumbers(object):

    def __init__(self):
        self.prefix_num = [1]

    def add(self, num):
        """
        :type num: int
        :rtype: None
        """
        if num == 0:
            self.prefix_num = [1]
            return
        self.prefix_num.append(self.prefix_num[-1] * num)
        
    def getProduct(self, k):
        """
        :type k: int
        :rtype: int
        """
        if k >= len(self.prefix_num):
            return 0
        return self.prefix_num[-1] // self.prefix_num[-k-1]



# Your ProductOfNumbers object will be instantiated and called as such:
# obj = ProductOfNumbers()
# obj.add(num)
# param_2 = obj.getProduct(k)
# @lc code=end



#
# @lcpr case=start
# ["ProductOfNumbers","add","add","add","add","add","getProduct","getProduct","getProduct","add","getProduct"]\n[[],[3],[0],[2],[5],[4],[2],[3],[4],[8],[2]]\n
# @lcpr case=end

#

