#
# @lc app=leetcode.cn id=80 lang=python
# @lcpr version=30200
#
# [80] 删除有序数组中的重复项 II
#

# @lc code=start
class Solution(object):
    def removeDuplicates(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        slow = fast = 0
        num_count = 1

        while fast < len(nums):
            slow = fast + 1
            while slow < len(nums) and nums[slow] == nums[fast]:
                print(slow)
                if num_count > 1:
                    nums.pop(slow)
                else:
                    slow += 1
                num_count += 1
            fast = slow
            num_count = 1
        
# @lc code=end



#
# @lcpr case=start
# [1,1,1,2,2,3]\n
# @lcpr case=end

# @lcpr case=start
# [0,0,1,1,1,1,2,3,3]\n
# @lcpr case=end

#

