#
# @lc app=leetcode.cn id=724 lang=python
# @lcpr version=30200
#
# [724] 寻找数组的中心下标
#

# @lc code=start
class Solution(object):
    def pivotIndex(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        pre_nums = [0]+nums+[0]
        
        for i in range(1, len(pre_nums)-1):
            left_sum = sum(pre_nums[:i])
            right_sum = sum(pre_nums[i+1:])
            if left_sum == right_sum:
                return i-1
        return -1
        
# @lc code=end


#
# @lcpr case=start
# [1, 7, 3, 6, 5, 6]\n
# @lcpr case=end

# @lcpr case=start
# [1, 2, 3]\n
# @lcpr case=end

# @lcpr case=start
# [2, 1, -1]\n
# @lcpr case=end

#

