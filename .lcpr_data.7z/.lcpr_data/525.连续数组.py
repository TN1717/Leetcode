#
# @lc app=leetcode.cn id=525 lang=python
# @lcpr version=30200
#
# [525] 连续数组
#

# @lc code=start
class Solution(object):
    def findMaxLength(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        ## 0当做-1
        tran_nums = list(map(lambda x:2*x-1, nums))
        presum_nums = [0]
        for i in range(1, len(tran_nums)+1):
            presum_nums.append(tran_nums[i-1]+presum_nums[i-1])
        print(presum_nums)
        value_index = {}
        res = 0
        for i in range(len(presum_nums)):
            if presum_nums[i] not in value_index:
                value_index[presum_nums[i]] = i
            else:
                res = max(res, i - value_index[presum_nums[i]])
        return res
    ### 遍历一次先0转-1，再遍历一次字典存当前元素所有的前缀和{sum:length} 输出求和为0的最大长度
        
# @lc code=end


#
# @lcpr case=start
# [0,1]\n
# @lcpr case=end

# @lcpr case=start
# [0,1,0]\n
# @lcpr case=end

# @lcpr case=start
# [0,1,1,1,1,1,0,0,0]\n
# @lcpr case=end

#

