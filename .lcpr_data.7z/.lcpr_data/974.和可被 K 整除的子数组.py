#
# @lc app=leetcode.cn id=974 lang=python
# @lcpr version=30200
#
# [974] 和可被 K 整除的子数组
#

# @lc code=start
class Solution(object):
    def subarraysDivByK(self, nums, k):
        """
        :type nums: List[int]
        :type k: int
        :rtype: int
        """
        ## 构造前缀和数组
        presum = [0]
        res = 0
        remaind_count = {0:1}

        for i in range(len(nums)):
            presum.append(nums[i] + presum[i])
            remaind = presum[-1] % k
            res += remaind_count.get(remaind, 0)
            remaind_count[remaind] = remaind_count.get(remaind, 0) + 1
        return res   

        
# @lc code=end



#
# @lcpr case=start
# [4,5,0,-2,-3,1]\n5\n
# @lcpr case=end

# @lcpr case=start
# [5]\n9\n
# @lcpr case=end

#

