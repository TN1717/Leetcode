#
# @lc app=leetcode.cn id=1329 lang=python
# @lcpr version=30200
#
# [1329] 将矩阵按对角线排序
#

# @lc code=start
class Solution(object):
    def diagonalSort(self, mat):
        """
        :type mat: List[List[int]]
        :rtype: List[List[int]]
        """
        ## 解法 1：取相邻两行，去掉头尾，交换中间元素即可 一直遍历

        flag = [False]
        while False in flag:
            flag = [True]
            for r in range(len(mat)-1):
                for c in range(len(mat[r])-1):
                    if mat[r][c] > mat[r+1][c+1]:
                        temp = mat[r][c]
                        mat[r][c] = mat[r+1][c+1]
                        mat[r+1][c+1] = temp
                        flag.append(False)
                    else:
                        flag.append(True)

            print(mat)
        return mat
        ## 解法 2 转一维List取数
        # temp_list = []
        # len_r = len(mat[0])
        # k = len_r+1      # 两数间距 k
        # for r in mat:
        #     temp_list.extend(r)
        # print(temp_list[:len(mat[0])])
        # for i in range(k):
        #     ## 比较
        #     if i != len(mat[0])-1:
        #         ilist = [i + j*k for j in range(-1*((i - len(temp_list))//k))]
        #         vlist = [temp_list[i + j*k] for j in range(-1*((i - len(temp_list))//k))]
        #         print("ilist-----", ilist)
        #         print("vlist-----", vlist)
        #         new_vlist = []
        #         while len(vlist) > 0:
        #             min_value = min(vlist)
        #             vlist.remove(min_value)
        #             new_vlist.append(min_value)
                
        #         for n, idx in enumerate(ilist):
        #             temp_list[idx] = new_vlist[n]
        #         print("new_vlist------", new_vlist)
        # print(temp_list)
        # ## 一维数组转二维
        # for i, v in enumerate(temp_list):
        #     if v:
        #         r = i / len(mat[0])
        #         c = i - r*len(mat[0])
        #         mat[r][c] = v
        # return mat

        
# @lc code=end



#
# @lcpr case=start
# [[3,3,1,1],[2,2,1,2],[1,1,1,2]]\n
# @lcpr case=end

# @lcpr case=start
# [[11,25,66,1,69,7],[23,55,17,45,15,52],[75,31,36,44,58,8],[22,27,33,25,68,4],[84,28,14,11,5,50]]\n
# @lcpr case=end

#

