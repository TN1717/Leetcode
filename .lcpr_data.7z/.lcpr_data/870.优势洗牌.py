#
# @lc app=leetcode.cn id=870 lang=python
# @lcpr version=30200
#
# [870] 优势洗牌
#

# @lc code=start
class Solution(object):
    def advantageCount(self, nums1, nums2):
        """
        :type nums1: List[int]
        :type nums2: List[int]
        :rtype: List[int]
        """
        ## nums1和nums2都排序
        nums1 = sorted(nums1)
        index_nums2 = [(index, value) for index, value in enumerate(nums2)]
        index_nums2.sort(key=lambda x: x[1], reverse=True)
        
        left, right = 0, len(nums1)-1
        result = [0] * len(nums1)

        for index, value in index_nums2:
            if nums1[right] > value:
                result[index] = nums1[right]
                right -= 1
            else:
                result[index] = nums1[left]
                left += 1

        return result
        
# @lc code=end



#
# @lcpr case=start
# [2,7,11,15]\n[1,10,4,11]\n
# @lcpr case=end

# @lcpr case=start
# [12,24,8,32]\n[13,25,32,11]\n
# @lcpr case=end

#

