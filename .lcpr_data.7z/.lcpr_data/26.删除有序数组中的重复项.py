#
# @lc app=leetcode.cn id=26 lang=python
# @lcpr version=30104
#
# [26] 删除有序数组中的重复项
#

# @lc code=start
class Solution(object):
    def removeDuplicates(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        p = 0
        while 1:
            if p >=len(nums)-1:
                break
            if nums[p] == nums[p+1]:
                nums.pop(p)
            else:
                p += 1
        print(nums)
        return len(nums)
        
# @lc code=end



#
# @lcpr case=start
# [1,1,2]\n
# @lcpr case=end

# @lcpr case=start
# [0,0,1,1,1,2,2,3,3,4]\n
# @lcpr case=end

#

