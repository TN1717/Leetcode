#
# @lc app=leetcode.cn id=167 lang=python
# @lcpr version=30104
#
# [167] 两数之和 II - 输入有序数组
#

# @lc code=start
class Solution(object):
    def twoSum(self, numbers, target):
        """
        :type numbers: List[int]
        :type target: int
        :rtype: List[int]
        """
        right = len(numbers)-1
        left = 0
        while left <= right:
            sum_nums = numbers[left] + numbers[right]
            if sum_nums == target:
                return [left + 1, right + 1]
            elif sum_nums > target:
                right -= 1
            else:
                left += 1

# @lc code=end



#
# @lcpr case=start
# [2,7,11,15]\n9\n
# @lcpr case=end

# @lcpr case=start
# [2,3,4]\n6\n
# @lcpr case=end

# @lcpr case=start
# [-1,0]\n-1\n
# @lcpr case=end

#

