#
# @lc app=leetcode.cn id=304 lang=python
# @lcpr version=30200
#
# [304] 二维区域和检索 - 矩阵不可变
#

# @lc code=start
class NumMatrix(object):

    def __init__(self, matrix):
        """
        :type matrix: List[List[int]]
        """
        m = len(matrix)
        n = len(matrix[0])
        if m==0 or n==0:
            return
        self.sumMat = [[0] * (n+1) for _ in range(m+1)]
        for i in range(1, m+1):
            for j in range(1, n+1):
                self.sumMat[i][j] = self.sumMat[i-1][j]+self.sumMat[i][j-1]-self.sumMat[i-1][j-1] + matrix[i-1][j-1]
        
    def sumRegion(self, row1, col1, row2, col2):
        """
        :type row1: int
        :type col1: int
        :type row2: int
        :type col2: int
        :rtype: int
        """
        return (self.sumMat[row2+1][col2+1] + self.sumMat[row1][col1] - self.sumMat[row1][col2+1] - self.sumMat[row2+1][col1])


# Your NumMatrix object will be instantiated and called as such:
# obj = NumMatrix(matrix)
# param_1 = obj.sumRegion(row1,col1,row2,col2)
# @lc code=end


#
# @lcpr case=start
# ["NumMatrix","sumRegion","sumRegion","sumRegion"]\n[[[[3,0,1,4,2],[5,6,3,2,1],[1,2,0,1,5],[4,1,0,1,7],[1,0,3,0,5]]],[2,1,4,3],[1,1,2,2],[1,2,2,4]]\n
# @lcpr case=end

#

