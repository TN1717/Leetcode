#
# @lc app=leetcode.cn id=1109 lang=python
# @lcpr version=30200
#
# [1109] 航班预订统计
#

# @lc code=start
class Solution(object):
    def corpFlightBookings(self, bookings, n):
        """
        :type bookings: List[List[int]]
        :type n: int
        :rtype: List[int]
        """
        result = [0] * (n + len(bookings))
        for item in bookings:
            left, right = item[0] - 1, item[1] - 1
            result[left] += item[2]
            result[right+1] += -item[2]

        for i in range(len(result)-1):
            result[i+1] += result[i]
        result = result[:n]
        return result

        
# @lc code=end



#
# @lcpr case=start
# [[1,2,10],[2,3,20],[2,5,25]]\n5\n
# @lcpr case=end

# @lcpr case=start
# [[1,2,10],[2,2,15]]\n2\n
# @lcpr case=end

#

