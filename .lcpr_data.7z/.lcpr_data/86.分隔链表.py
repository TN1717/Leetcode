#
# @lc app=leetcode.cn id=86 lang=python
# @lcpr version=30005
#
# [86] 分隔链表
#


# @lcpr-template-start

# @lcpr-template-end
# @lc code=start
# Definition for singly-linked list.
# class ListNode(object):
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution(object):
    def partition(self, head, x):
        """
        :type head: Optional[ListNode]
        :type x: int
        :rtype: Optional[ListNode]
        """
        dummy1 = ListNode(-1)       # 存放小于x的链表的虚拟头结点
        dummy2 = ListNode(-1)       # 存放大于等于x的链表的虚拟头结点
        p1, p2 = dummy1, dummy2
        p = head
        while p:
            if p.val < x:
                p1.next = p
                p1 = p1.next
            else:
                p2.next = p
                p2 = p2.next
            # p = p.next
            
            # 断开原链表中的每个节点的 next 指针
            temp = p.next
            p.next = None
            p = temp

        # if p1.val:
        #     p1.next = dummy2.next
        # else:
        p1.next = dummy2.next

        return dummy1.next

        
        
# @lc code=end



#
# @lcpr case=start
# [1,4,3,2,5,2]\n3\n
# @lcpr case=end

# @lcpr case=start
# [2,1]\n2\n
# @lcpr case=end

#

