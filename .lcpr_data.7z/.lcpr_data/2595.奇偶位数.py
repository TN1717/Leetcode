#
# @lc app=leetcode.cn id=2595 lang=python
# @lcpr version=30005
#
# [2595] 奇偶位数
#


# @lcpr-template-start

# @lcpr-template-end
# @lc code=start
class Solution(object):
    def evenOddBit(self, n):
        """
        :type n: int
        :rtype: List[int]
        """
        binary = list(map(int, reversed(list(bin(n).replace('0b', '')))))
        print(binary)
        even = 0
        odd = 0

        index = [a for a, b in enumerate(binary) if b == 1]
        print(index)
        
        for i in index:
            if i % 2 == 0:
                even += 1
            else:
                odd += 1

        return [even, odd]

        
# @lc code=end



#
# @lcpr case=start
# 50\n
# @lcpr case=end

# @lcpr case=start
# 2\n
# @lcpr case=end

#

