#
# @lc app=leetcode.cn id=75 lang=python
# @lcpr version=30200
#
# [75] 颜色分类
#

# @lc code=start
class Solution(object):
    def sortColors(self, nums):
        """
        :type nums: List[int]
        :rtype: None Do not return anything, modify nums in-place instead.
        """
        fast = slow = 0
        ## 移动2到最后-->移动1到最后-->返回
        while fast < len(nums):
            if nums[fast] != 2:
                nums[slow] = nums[fast]
                nums[fast] = 2 if slow != fast else nums[slow]
                slow += 1
            fast += 1
        
        print("move 2 ----", nums)

        fast = slow = 0
        while fast < len(nums) and nums[fast] != 2:

            if nums[fast] != 1:
                nums[slow] = nums[fast]
                nums[fast] = 1 if slow != fast else nums[slow]
                slow += 1
            fast += 1
        print("move 1 ----", nums)
        
   
# @lc code=end



#
# @lcpr case=start
# [2,0,2,1,1,0]\n
# @lcpr case=end

# @lcpr case=start
# [2,0,1]\n
# @lcpr case=end

#

