#
# @lc app=leetcode.cn id=867 lang=python
# @lcpr version=30200
#
# [867] 转置矩阵
#

# @lc code=start
class Solution(object):
    def transpose(self, matrix):
        """
        :type matrix: List[List[int]]
        :rtype: List[List[int]]
        """
        matrix_t = [[0 for r in range(len(matrix))] for c in range(len(matrix[0]))]
        for r in range(len(matrix)):
            for c in range(len(matrix[r])):
                matrix_t[c][r] = matrix[r][c]
        return matrix_t
        
# @lc code=end


#
# @lcpr case=start
# [[1,2,3],[4,5,6],[7,8,9]]\n
# @lcpr case=end

# @lcpr case=start
# [[1,2,3],[4,5,6]]\n
# @lcpr case=end

#

