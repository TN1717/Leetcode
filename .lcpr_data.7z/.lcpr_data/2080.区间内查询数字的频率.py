#
# @lc app=leetcode.cn id=2080 lang=python
# @lcpr version=30005
#
# [2080] 区间内查询数字的频率
#


# @lcpr-template-start

# @lcpr-template-end
# @lc code=start
class RangeFreqQuery(object):

    def __init__(self, arr):
        """
        :type arr: List[int]
        """
        self.arr = arr
        

    def query(self, left, right, value):
        """
        :type left: int
        :type right: int
        :type value: int
        :rtype: int
        """
        if right >= len(self.arr) or left < 0:
            return None
        else:
            tmp_list = self.arr[left : right + 1]
            tmp_dict = {}
            for key in tmp_list:
                tmp_dict[key] = tmp_dict.get(key, 0) + 1

            print(tmp_dict)
            if tmp_dict.has_key(value):
                return tmp_dict[value]
            else:
                return 0
        


# Your RangeFreqQuery object will be instantiated and called as such:
# obj = RangeFreqQuery(arr)
# param_1 = obj.query(left,right,value)
# @lc code=end



#
# @lcpr case=start
# ["RangeFreqQuery", "query", "query"][[[12, 33, 4, 56, 22, 2, 34, 33, 22, 12, 34, 56]], [1, 2, 4], [0, 11, 33]]\n
# @lcpr case=end

#

