#
# @lc app=leetcode.cn id=92 lang=python
# @lcpr version=30104
#
# [92] 反转链表 II
#

# @lc code=start
# Definition for singly-linked list.
# class ListNode(object):
#     def __init__(self, val=0, next=None):
#         self.val = val
#         self.next = next
class Solution(object):
    def reverseBetween(self, head, left, right):
        """
        :type head: Optional[ListNode]
        :type left: int
        :type right: int
        :rtype: Optional[ListNode]
        """
        left = left - 1
        right = right - 1
        if left > right or left < 0 or right < 0:
            return None
        result = []
        n = dummy = ListNode(-1)
        i = 0
        while i <= right:
            if i >= left:
                result.append(head)
            else:
                n.next = head
                n = n.next
            i += 1
            head = head.next
        while result:
            temp = result.pop()
            temp.next = None
            n.next = temp
            n = n.next
        n.next = head
        return dummy.next
        
# @lc code=end



#
# @lcpr case=start
# [1,2,3,4,5]\n2\n4\n
# @lcpr case=end

# @lcpr case=start
# [5]\n1\n1\n
# @lcpr case=end

#

