#
# @lc app=leetcode.cn id=151 lang=python
# @lcpr version=30104
#
# [151] 反转字符串中的单词
#

# @lc code=start
class Solution(object):
    def reverseWords(self, s):
        """
        :type s: str
        :rtype: str
        """
        s_list = s.split(" ")
        s_list = list(filter(lambda x: x!='', s_list))[::-1]
        output = ""
        for i in range(len(s_list)-1):
            output += s_list[i]+" "
        output += s_list[-1]
        return output
        
# @lc code=end



#
# @lcpr case=start
# "the sky is blue"\n
# @lcpr case=end

# @lcpr case=start
# "  hello world  "\n
# @lcpr case=end

# @lcpr case=start
# "a good   example"\n
# @lcpr case=end

#

